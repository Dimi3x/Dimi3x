CRISPR-GPU Miner (standalone)
=============================

Purpose
-------
- Standalone Bash + Python pipeline to mine novel CRISPR/Cas operons from assembled MAGs.
- Uses MMseqs2 GPU clustering for sensitivity; Python handles CRISPR array detection, ORF calls, operon assembly, and ranking.
- Outputs full operons: CRISPR array + flanking proteins + adjacency metadata for downstream FoldSeek/ESM3 or database building.

Pipeline overview
-----------------
- (Optional, recommended) Prodigal meta-mode ORF calling per MAG to improve protein accuracy.
- Parse assembled MAG FASTA files.
- Detect CRISPR arrays using repeat/spacer heuristics (min 3 repeats, repeat 23-47 bp, spacers 20-60 bp).
- If Prodigal is not used: call ORFs on both strands with the built-in lightweight caller.
- Assemble operons: arrays plus ORFs within a configurable flank window (default 10 kbp).
- Score/rank operons by array quality, proximity and density of ORFs, length sanity, and repeat/spacer consistency.
- Cluster proteins with MMseqs2 GPU `linclust` for higher sensitivity on low-identity Cas variants.
- Optional GPU search against a provided CRISPR/Cas reference DB to tag known families and highlight novel clusters.
- (Optional) Downstream structural and embedding passes:
  - ESM3 embeddings on `operon_proteins.faa` or cluster reps to prioritize novel candidates.
  - AlphaFold3 on prioritized reps to obtain structures.
  - FoldSeek on AlphaFold3 models to search structural space and find remote homologs.

Key files
---------
- `crispr_operon_miner.py`: Python core for array detection, ORF calling, operon scoring, JSON/TSV/FASTA outputs.
- `crispr_gpu_pipeline.sh`: Bash driver to run the miner and MMseqs2 GPU clustering/search.

Ranking rationale
-----------------
- Array quality (repeat length in canonical range, ≥3 spacers, spacer length variability) dominates the score.
- Proximity and density of ORFs around the array are boosted; unrealistic protein lengths penalized.
- Optional MMseqs2 hit density to known DB (if provided) is recorded so novel clusters stand out.
- This ranking helps triage candidates; keep it but always review high-scoring outliers.

Usage (quick start)
-------------------
```bash
# Requires: python3, mmseqs (GPU build), writable tmp space
./crispr_gpu_pipeline.sh /path/to/mags /path/to/output \
  --use-prodigal \
  --known-db /path/to/crispr_db  # optional MMseqs2 DB
```
- Outputs:
  - `operons.json`: structured operon calls with scores.
  - `operons.tsv`: tabular summary for quick filtering.
  - `operon_proteins.faa`: proteins near arrays (for clustering/search).
  - `clusters.tsv`: MMseqs2 GPU linclust results.
  - `known_hits.tsv`: optional GPU search annotations if a DB is given.
  - `tmp/prodigal/*.faa|gff`: Prodigal outputs when enabled (kept for reuse).

Integration hooks
-----------------
- FoldSeek: run on `operon_proteins.faa` or cluster representatives from `clusters.tsv`.
- ESM3: embed `operon_proteins.faa` sequences; use operon scores to prioritize.
- MMseqs2: already used for GPU clustering; reuse created DBs for further searches.
- AlphaFold3: model prioritized cluster representatives (e.g., top-ranked novel clusters). Run FoldSeek on the resulting models to discover remote structural neighbors; keep embeddings/novelty metrics to decide which proteins to model first.
