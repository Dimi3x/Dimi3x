#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <mag_fasta_dir_or_file> <output_dir> [--known-db /path/to/mmseqs_db] [--use-prodigal]" >&2
  exit 1
fi

INPUT_PATH="$1"
OUT_DIR="$2"
shift 2 || true

KNOWN_DB=""
USE_PRODIGAL=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --known-db)
      KNOWN_DB="$2"
      shift 2
      ;;
    --use-prodigal)
      USE_PRODIGAL=1
      shift 1
      ;;
    *)
      echo "Unknown option: $1" >&2
      exit 1
      ;;
  esac
done

if ! command -v mmseqs >/dev/null 2>&1; then
  echo "mmseqs not found in PATH" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON=${PYTHON:-python3}

mkdir -p "${OUT_DIR}"
TMP_DIR="${OUT_DIR}/tmp"
mkdir -p "${TMP_DIR}"

OPERON_JSON="${OUT_DIR}/operons.json"
OPERON_TSV="${OUT_DIR}/operons.tsv"
PROTEINS="${OUT_DIR}/operon_proteins.faa"

PRODIGAL_DIR="${TMP_DIR}/prodigal"
if [[ "${USE_PRODIGAL}" -eq 1 ]]; then
  if ! command -v prodigal >/dev/null 2>&1; then
    echo "prodigal requested but not found in PATH" >&2
    exit 1
  fi
  mkdir -p "${PRODIGAL_DIR}"
  echo "[1/4] Running Prodigal on MAGs..."
  mapfile -t FASTA_FILES < <(find "${INPUT_PATH}" -maxdepth 1 -type f \( -name "*.fa" -o -name "*.fna" -o -name "*.fasta" -o -name "*.fas" \))
  if [[ ${#FASTA_FILES[@]} -eq 0 ]]; then
    echo "No FASTA files found under ${INPUT_PATH}" >&2
    exit 1
  fi
  for f in "${FASTA_FILES[@]}"; do
    base="$(basename "$f")"
    stem="${base%.*}"
    prodigal -i "$f" -a "${PRODIGAL_DIR}/${stem}.faa" -f gff -o "${PRODIGAL_DIR}/${stem}.gff" -p meta
  done
fi

echo "[2/4] Detecting CRISPR arrays and operons with Python..."
MINER_ARGS=(
  --input "${INPUT_PATH}"
  --output-json "${OPERON_JSON}"
  --output-tsv "${OPERON_TSV}"
  --output-proteins "${PROTEINS}"
)
if [[ "${USE_PRODIGAL}" -eq 1 ]]; then
  MINER_ARGS+=(--prodigal-dir "${PRODIGAL_DIR}")
fi
${PYTHON} "${SCRIPT_DIR}/crispr_operon_miner.py" "${MINER_ARGS[@]}"

echo "[3/4] MMseqs2 GPU linclust on operon proteins..."
PROT_DB="${TMP_DIR}/proteins.db"
CLUST="${TMP_DIR}/clusters"
mmseqs createdb "${PROTEINS}" "${PROT_DB}"
mmseqs linclust "${PROT_DB}" "${CLUST}" "${TMP_DIR}/linclust_tmp" \
  --min-seq-id 0.3 --cov-mode 1 -c 0.6 --cluster-mode 2 --gpu 1
mmseqs createtsv "${PROT_DB}" "${PROT_DB}" "${CLUST}" "${OUT_DIR}/clusters.tsv"

if [[ -n "${KNOWN_DB}" ]]; then
  echo "[4/4] GPU search against known CRISPR/Cas DB: ${KNOWN_DB}"
  KNOWN_RES="${TMP_DIR}/known_hits"
  mmseqs search "${PROT_DB}" "${KNOWN_DB}" "${KNOWN_RES}" "${TMP_DIR}/search_tmp" --gpu 1
  mmseqs createtsv "${PROT_DB}" "${KNOWN_DB}" "${KNOWN_RES}" "${OUT_DIR}/known_hits.tsv"
else
  echo "[4/4] Skipping known DB search (no --known-db provided)."
fi

echo "Done. Outputs:"
echo "  - ${OPERON_JSON}"
echo "  - ${OPERON_TSV}"
echo "  - ${PROTEINS}"
echo "  - ${OUT_DIR}/clusters.tsv"
[[ -n "${KNOWN_DB}" ]] && echo "  - ${OUT_DIR}/known_hits.tsv"
